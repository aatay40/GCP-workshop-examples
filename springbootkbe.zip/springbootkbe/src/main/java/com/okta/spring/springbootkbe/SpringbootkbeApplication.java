package com.okta.spring.springbootkbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootkbeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootkbeApplication.class, args);
	}

}
